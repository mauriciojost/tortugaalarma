#!/bin/bash

PATH=/home/mauri/mpibin/bin:$PATH
export PATH

LD_LIBRARY_PATH=/home/mauri/mpibin/lib
export LD_LIBRARY_PATH

